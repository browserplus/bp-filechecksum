The "Internal SDK" contains tools meaningful to developers.  In includes
the following tools:

ServiceInstaller:  A command line tool capable of packaging and pushing
a BrowserPlus service to a distribution server (that supports the required
WSAPI.  This tool is only useful in a controlled testing environment.

ProtocolLibrary: A shared library that can be used to run and communicate
with the BrowserPlus daemon.
