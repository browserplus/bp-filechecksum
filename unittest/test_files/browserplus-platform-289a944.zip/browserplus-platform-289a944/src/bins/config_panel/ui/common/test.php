<?php
echo str_replace("main.js", "test_js.php", file_get_contents("index.html"));
?>